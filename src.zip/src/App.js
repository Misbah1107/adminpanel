import logo from './logo.svg';
import './App.css';
import AppRouter from './config/router';
import store from './store'
import { Provider } from 'react-redux';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>

   <Provider store={store}>
      <AppRouter />
    </Provider>
    </div>
  );
}
 export default App