import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from '../containers/Home';
import Admin from '../containers/admin';
import Costomer from '../containers/cotumerdetials';

function AppRouter() {
    return (
        <Router>
            <Switch>
                <Route exact path="/" component={Admin} />
                <Route exact path="/costumer" component={Costomer} />
            </Switch>
        </Router>
    )
}

export default AppRouter;