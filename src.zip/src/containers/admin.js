import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux"
import { Link } from "react-router-dom";
import { AllUser } from "../store/action";
import { Nav, Navbar, Container } from 'react-bootstrap'
// import { Link } from 'react-router-dom'

function Admin() {
    const state = useSelector(state => state)
    console.log(state.user)
    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(AllUser())
    }, [])

    return (
        <div>
            <Navbar className="navbarr" expand="lg">
                <Container>
                    <Navbar.Brand href="#home">ADMIN <span>PANEL</span></Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            <Link className="links" to="/">Deshboard</Link>
                            <Link className="links" to="/costumer">Costumer detials</Link>

                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            <div className="main-1">
                <div className="main mt-5">



                    <table id="customers">
                        <tr>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Costumer Email</th>
                            {/* <th>View details</th> */}
                        </tr>


                        {state.user ? state.user.map((e, i) => {
                            return (
                                <tbody>
                                    <tr>
                                        <td>{e.name}</td>
                                        <td>{e.price}</td>
                                        <td>{e.email}</td>
                                        {/* <td><span className="status delivered"><Link style={{ textDecoration: "none" }}>View</Link></span></td> */}
                                    </tr>
                                </tbody>
                            )
                        }) : <div class="spinner-border" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>}

                    </table>
                </div>
            </div>


        </div>
    );
}

export default Admin;
