import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux"
import { Link } from "react-router-dom";
import { AllUser } from "../store/action";
import { Nav, Navbar, Container } from 'react-bootstrap'

function Costomer() {
    const state = useSelector(state => state)
    console.log(state.user)
    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(AllUser())
    }, [])
    console.log(state.user)

    return (
        <div>
            <Navbar className="navbarr" expand="lg">
                <Container>
                    <Navbar.Brand href="#home">ADMIN <span>PANEL</span></Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            <Link className="links" to="/">Deshboard</Link>
                            <Link className="links" to="/costumer">Costumer detials</Link>

                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            <div className="main-1">
                <div className="main mt-5">



                    <table id="customers">
                        <tr>
                            <th>Name</th>
                            <th>Costumer Email</th>
                            <th>Phone number</th>
                            <th>Cnic</th>
                            <th>Adrass</th>
                            <th>Room Type</th>
                            <th>Size</th>
                            <th>stay</th>
                            <th>Price</th>
                        </tr>


                        {state.user ? state.user.map((e, i) => {
                            return (
                                <tbody>
                                    <tr>
                                        <td>{e.name}</td>
                                        <td>{e.email}</td>
                                        <td>{e.phonenumber}</td>
                                        <td>{e.cnic}</td>
                                        <td>{e.addreas}</td>
                                        <td>{e.type}</td>
                                        <td>{e.size}</td>
                                        <td>{e.stay}</td>
                                        <td>{e.price}</td>
                                    </tr>
                                </tbody>
                            )
                        }) : <div class="spinner-border" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>}

                    </table>
                </div>
            </div>


        </div>
    );
}

export default Costomer;
