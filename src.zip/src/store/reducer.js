const INITAIL_STATE = {
  email:"example@gail.com",
  user:""
}

export default (state = INITAIL_STATE, action) => {

    switch (action.type) {
        case "GETALLUSER":
          return ({
            ...state,
          user:action.alluser
        })
        default:
          return state
      }
}