import React from 'react'
import { Firebase, provider, googleprovider } from "../config/firbase";




const AllUser = () => {
    return (dispatch) => {
        Firebase.database().ref('users').once('value', (data) => {
            // for(var key in data.val()){
            //     console.log(key)
            // }
            
            const userdata=Object.values(data.val())
            dispatch({ type: "GETALLUSER", alluser: userdata })
        })
    }
}
export{
    AllUser,
}